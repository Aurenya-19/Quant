import { Sidebar } from "./Sidebar";
import { Menu, Bell } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, MessageSquare, Trophy, Users, User, DollarSign, Code2, Calendar, Bot, Briefcase, Zap, Shield, Radio, Rocket } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const links = [
    { href: "/", icon: LayoutDashboard, label: "Home" },
    { href: "/nexus", icon: Rocket, label: "Nexus (Discovery)" },
    { href: "/intel", icon: Radio, label: "Intel Feed" },
    { href: "/chat", icon: MessageSquare, label: "Chat" },
    { href: "/leaderboard", icon: Trophy, label: "Leaderboard" },
    { href: "/communities", icon: Users, label: "Communities" },
    { href: "/bounties", icon: DollarSign, label: "Bounties" },
    { href: "/snippets", icon: Code2, label: "Snippets" },
    { href: "/events", icon: Calendar, label: "Events" },
    { href: "/assistant", icon: Bot, label: "AI Assistant" },
    { href: "/workspace", icon: Briefcase, label: "Workspace" },
    { href: "/focus", icon: Zap, label: "Focus Mode" },
    { href: "/security", icon: Shield, label: "Security" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="flex min-h-screen bg-background text-foreground selection:bg-primary/30">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b border-border/50 bg-card/50 backdrop-blur-lg sticky top-0 z-50">
          <h1 className="text-xl font-display font-bold text-primary text-glow">QC</h1>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-muted-foreground">
              <Bell className="w-5 h-5" />
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-primary">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-card border-r border-border/50">
                <div className="flex flex-col h-full pt-10">
                   <nav className="flex-1 space-y-2">
                    {links.map((link) => {
                      const Icon = link.icon;
                      const isActive = location === link.href;
                      return (
                        <Link 
                          key={link.href} 
                          href={link.href}
                          className={cn(
                            "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
                            isActive 
                              ? "bg-primary/10 text-primary border border-primary/20" 
                              : "text-muted-foreground hover:text-primary hover:bg-primary/5"
                          )}
                        >
                          <Icon className="w-5 h-5" />
                          <span className="font-ui font-medium">{link.label}</span>
                        </Link>
                      );
                    })}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </header>
        
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
