import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, MessageSquare, Trophy, Users, User, DollarSign, Code2, Calendar, Bot, Briefcase, Zap, Shield, Radio, Rocket } from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();

  const links = [
    { href: "/", icon: LayoutDashboard, label: "Home" },
    { href: "/nexus", icon: Rocket, label: "Nexus (Discovery)" },
    { href: "/intel", icon: Radio, label: "Intel Feed" },
    { href: "/chat", icon: MessageSquare, label: "Chat" },
    { href: "/leaderboard", icon: Trophy, label: "Leaderboard" },
    { href: "/communities", icon: Users, label: "Communities" },
    { href: "/bounties", icon: DollarSign, label: "Bounties" },
    { href: "/snippets", icon: Code2, label: "Snippets" },
    { href: "/events", icon: Calendar, label: "Events" },
    { href: "/assistant", icon: Bot, label: "AI Assistant" },
    { href: "/workspace", icon: Briefcase, label: "Workspace" },
    { href: "/focus", icon: Zap, label: "Focus Mode" },
    { href: "/security", icon: Shield, label: "Security" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 border-r border-border/50 bg-card/50 backdrop-blur-xl h-screen sticky top-0">
      <div className="p-6">
        <h1 className="text-2xl font-display font-bold text-primary text-glow">
          QUANTUM<br/>CIRCLE
        </h1>
      </div>
      <nav className="flex-1 px-4 space-y-2">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link 
              key={link.href} 
              href={link.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group",
                isActive 
                  ? "bg-primary/10 text-primary border border-primary/20 shadow-[0_0_15px_rgba(0,255,255,0.1)]" 
                  : "text-muted-foreground hover:text-primary hover:bg-primary/5"
              )}
            >
              <Icon className={cn("w-5 h-5", isActive && "animate-pulse")} />
              <span className="font-ui font-medium tracking-wide">{link.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="p-6 border-t border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-primary to-accent p-[2px]">
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div>
            <p className="font-ui font-bold text-sm">NeonWalker</p>
            <p className="text-xs text-muted-foreground">Level 42</p>
          </div>
        </div>
      </div>
    </div>
  );
}
