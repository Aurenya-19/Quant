import { Layout } from "@/components/Layout";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Trophy, Medal, Crown, TrendingUp, Zap, Shield, Brain, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function Leaderboard() {
  const categories = [
    { id: "global", label: "Global Elite", icon: Trophy },
    { id: "trending", label: "Trending", icon: TrendingUp },
    { id: "ai", label: "AI & ML", icon: Brain },
    { id: "web3", label: "Web3 & Blockchain", icon: Zap },
    { id: "cybersec", label: "Cyber Security", icon: Shield },
  ];

  // Mock data generator
  const generateUsers = (category: string) => {
    return Array.from({ length: 10 }).map((_, i) => ({
      rank: i + 1,
      name: `${category === 'global' ? 'User' : category}_${i + 1}`,
      points: Math.floor(15000 * (1 - i * 0.08)),
      level: Math.floor(50 * (1 - i * 0.05)),
      status: i < 3 ? "Legend" : i < 6 ? "Elite" : "Pro",
      specialty: category === 'global' ? 'Full Stack' : category.toUpperCase()
    }));
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-end gap-4">
          <div>
            <Badge variant="outline" className="border-primary text-primary px-4 py-1 text-sm mb-2">Quantum Rankings</Badge>
            <h1 className="text-4xl font-display font-bold text-glow">Leaderboards</h1>
            <p className="text-muted-foreground max-w-lg mt-2">
              Dominate your niche. Rankings are updated daily based on contribution impact.
            </p>
          </div>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="p-4 flex items-center gap-3 cursor-help border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors">
                  <Info className="w-5 h-5 text-primary" />
                  <div className="text-left">
                    <p className="font-bold text-sm">Ranking System</p>
                    <p className="text-xs text-muted-foreground">How XP is calculated</p>
                  </div>
                </Card>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs bg-card border-border p-4">
                <div className="space-y-2">
                  <h4 className="font-bold text-primary">XP Breakdown</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• <span className="text-foreground">Code Commits:</span> +50 XP</li>
                    <li>• <span className="text-foreground">Bounty Complete:</span> +500-5000 XP</li>
                    <li>• <span className="text-foreground">Helpful Reply:</span> +20 XP</li>
                    <li>• <span className="text-foreground">Snippet Star:</span> +10 XP</li>
                  </ul>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <Tabs defaultValue="global" className="w-full">
          <TabsList className="w-full justify-start bg-card/30 border border-border/50 p-1 h-auto rounded-lg flex-wrap gap-1 mb-6">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <TabsTrigger 
                  key={cat.id} 
                  value={cat.id}
                  className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary/20 data-[state=active]:text-primary flex-1 md:flex-none"
                >
                  <Icon className="w-4 h-4" />
                  {cat.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          {categories.map((cat) => {
            const users = generateUsers(cat.id);
            return (
              <TabsContent key={cat.id} value={cat.id} className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                 {/* Top 3 Podium */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 items-end">
                  {/* 2nd Place */}
                  <div className="order-2 md:order-1 relative p-6 rounded-xl border border-border bg-card/30 flex flex-col items-center text-center hover:border-gray-400 transition-colors">
                    <Medal className="w-6 h-6 text-gray-400 mb-2" />
                    <div className="w-16 h-16 rounded-full mb-4 border-2 border-gray-400 overflow-hidden">
                      <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${users[1].name}`} alt={users[1].name} />
                    </div>
                    <h3 className="font-bold text-lg font-display">{users[1].name}</h3>
                    <p className="text-muted-foreground text-sm">{users[1].points.toLocaleString()} XP</p>
                  </div>

                  {/* 1st Place */}
                  <div className="order-1 md:order-2 relative p-8 rounded-xl border border-yellow-500/50 bg-yellow-500/10 flex flex-col items-center text-center scale-110 shadow-[0_0_30px_rgba(234,179,8,0.1)]">
                    <Crown className="w-8 h-8 text-yellow-400 mb-2 animate-bounce" />
                    <div className="w-24 h-24 rounded-full mb-4 border-4 border-yellow-400 overflow-hidden shadow-lg">
                      <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${users[0].name}`} alt={users[0].name} />
                    </div>
                    <h3 className="font-bold text-2xl font-display text-yellow-400">{users[0].name}</h3>
                    <p className="text-yellow-200/80 font-mono text-lg">{users[0].points.toLocaleString()} XP</p>
                    <Badge className="mt-2 bg-yellow-500/20 text-yellow-400 border-yellow-500/50">Champion</Badge>
                  </div>

                  {/* 3rd Place */}
                  <div className="order-3 relative p-6 rounded-xl border border-border bg-card/30 flex flex-col items-center text-center hover:border-amber-700 transition-colors">
                    <Medal className="w-6 h-6 text-amber-700 mb-2" />
                    <div className="w-16 h-16 rounded-full mb-4 border-2 border-amber-700 overflow-hidden">
                      <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${users[2].name}`} alt={users[2].name} />
                    </div>
                    <h3 className="font-bold text-lg font-display">{users[2].name}</h3>
                    <p className="text-muted-foreground text-sm">{users[2].points.toLocaleString()} XP</p>
                  </div>
                </div>

                {/* Full List */}
                <div className="rounded-xl border border-border/50 bg-card/30 overflow-hidden backdrop-blur-sm">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-white/5 border-border/50">
                        <TableHead className="w-[100px]">Rank</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Specialty</TableHead>
                        <TableHead>Level</TableHead>
                        <TableHead className="text-right">Points</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.slice(3).map((user) => (
                        <TableRow key={user.name} className="hover:bg-white/5 border-border/50">
                          <TableCell className="font-medium text-muted-foreground">#{user.rank}</TableCell>
                          <TableCell className="font-bold flex items-center gap-3">
                             <div className="w-6 h-6 rounded-full bg-muted overflow-hidden">
                                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} />
                             </div>
                             {user.name}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-primary/30 text-primary/80 text-xs">
                              {user.specialty}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono text-muted-foreground">Lvl {user.level}</TableCell>
                          <TableCell className="text-right font-mono text-primary">{user.points.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </Layout>
  );
}
