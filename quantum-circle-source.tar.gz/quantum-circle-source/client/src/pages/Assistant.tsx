import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, Sparkles, Send, Code } from "lucide-react";
import { useState } from "react";

export default function Assistant() {
  const [messages, setMessages] = useState([
    { role: "ai", content: "Greetings, Traveler. I am the Quantum Core AI. How can I assist you with your code or system architecture today?" }
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsgs = [...messages, { role: "user", content: input }];
    setMessages(newMsgs);
    setInput("");
    
    // Mock AI response
    setTimeout(() => {
      setMessages([...newMsgs, { role: "ai", content: "I've analyzed your request. To optimize that function, consider memoizing the heavy calculation. Here is a snippet..." }]);
    }, 1000);
  };

  return (
    <Layout>
      <div className="h-[calc(100vh-8rem)] flex flex-col gap-6">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-[0_0_20px_rgba(0,255,255,0.3)]">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold text-glow">Quantum Assistant</h1>
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <Sparkles className="w-3 h-3 text-accent" /> Powered by Neural Link v4.2
            </p>
          </div>
        </div>

        <Card className="flex-1 border-border/50 bg-card/30 backdrop-blur-sm flex flex-col overflow-hidden">
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-6 max-w-3xl mx-auto">
              {messages.map((msg, i) => (
                <div key={i} className={`flex gap-4 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === "ai" ? "bg-primary/20 text-primary" : "bg-muted"}`}>
                    {msg.role === "ai" ? <Bot className="w-4 h-4" /> : <div className="w-full h-full rounded-full overflow-hidden"><img src="https://api.dicebear.com/7.x/avataaars/svg?seed=NeonWalker" /></div>}
                  </div>
                  <div className={`p-4 rounded-2xl max-w-[80%] ${
                    msg.role === "ai" 
                      ? "bg-card/50 border border-border/50 rounded-tl-none" 
                      : "bg-primary text-primary-foreground rounded-tr-none"
                  }`}>
                    <p className="leading-relaxed">{msg.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t border-border/50 bg-card/50">
            <div className="max-w-3xl mx-auto flex gap-3">
               <Button variant="outline" size="icon" className="border-border/50 hover:text-primary">
                 <Code className="w-4 h-4" />
               </Button>
               <Input 
                 value={input}
                 onChange={e => setInput(e.target.value)}
                 onKeyDown={e => e.key === 'Enter' && handleSend()}
                 placeholder="Ask me anything about your code..." 
                 className="bg-background/50 border-primary/20 focus-visible:ring-primary"
               />
               <Button onClick={handleSend} className="bg-primary text-primary-foreground hover:bg-primary/90">
                 <Send className="w-4 h-4" />
               </Button>
            </div>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
