import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon, MapPin, Users, Video, Mic } from "lucide-react";

export default function Events() {
  const events = [
    {
      id: 1,
      title: "Global Quantum Hackathon",
      date: "Oct 15-17, 2024",
      time: "10:00 AM UTC",
      type: "Hackathon",
      attendees: 2400,
      image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2340&auto=format&fit=crop",
      status: "Registering"
    },
    {
      id: 2,
      title: "CyberSec Weekly Meetup",
      date: "Tomorrow",
      time: "18:00 UTC",
      type: "Audio Room",
      attendees: 45,
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2340&auto=format&fit=crop",
      status: "Upcoming"
    },
    {
      id: 3,
      title: "Future of UI Design Workshop",
      date: "Nov 02, 2024",
      time: "14:00 UTC",
      type: "Workshop",
      attendees: 120,
      image: "https://images.unsplash.com/photo-1558655146-d09347e0b7a9?q=80&w=2340&auto=format&fit=crop",
      status: "Upcoming"
    }
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-display font-bold mb-2 text-glow">Events & Hackathons</h1>
            <p className="text-muted-foreground">Connect, compete, and learn in real-time.</p>
          </div>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            <CalendarIcon className="w-4 h-4 mr-2" /> Host Event
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {events.map((event) => (
            <Card key={event.id} className="overflow-hidden border-border/50 bg-card/30 backdrop-blur-sm group">
              <div className="h-48 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10" />
                <img 
                  src={event.image} 
                  alt={event.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                />
                <Badge className="absolute top-4 left-4 z-20 bg-background/80 backdrop-blur-md border-none text-foreground">
                  {event.type}
                </Badge>
                {event.status === "Registering" && (
                  <Badge className="absolute top-4 right-4 z-20 bg-accent text-accent-foreground border-none animate-pulse">
                    Registering
                  </Badge>
                )}
              </div>
              
              <div className="p-6 space-y-4">
                <div>
                  <h3 className="text-xl font-display font-bold mb-2 group-hover:text-primary transition-colors">{event.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <CalendarIcon className="w-4 h-4" /> <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" /> <span>{event.attendees}</span>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border/50 flex items-center justify-between">
                   <div className="flex -space-x-2">
                     {[1, 2, 3].map(i => (
                       <div key={i} className="w-8 h-8 rounded-full border-2 border-background bg-muted overflow-hidden">
                         <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${event.title}${i}`} alt="Avatar" />
                       </div>
                     ))}
                     <div className="w-8 h-8 rounded-full border-2 border-background bg-muted flex items-center justify-center text-[10px] font-bold">
                       +99
                     </div>
                   </div>
                   <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
                     {event.type === 'Audio Room' ? <Mic className="w-4 h-4 mr-2" /> : <Video className="w-4 h-4 mr-2" />}
                     Join
                   </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}
