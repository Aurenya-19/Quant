import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Shield, Key, Lock, Smartphone, Eye, Activity, AlertTriangle, CheckCircle } from "lucide-react";
import { useState } from "react";

export default function Security() {
  const [twoFactor, setTwoFactor] = useState(true);
  const [publicProfile, setPublicProfile] = useState(false);
  const [loginAlerts, setLoginAlerts] = useState(true);

  const activityLog = [
    { id: 1, action: "Login Successful", device: "Chrome / Windows", location: "New York, USA", time: "2 minutes ago", status: "success" },
    { id: 2, action: "Password Changed", device: "Firefox / Mac", location: "New York, USA", time: "2 days ago", status: "warning" },
    { id: 3, action: "New API Key Generated", device: "Chrome / Windows", location: "New York, USA", time: "1 week ago", status: "success" },
  ];

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold text-glow">Security Center</h1>
            <p className="text-muted-foreground">Manage your account security and privacy settings.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Authentication Status */}
          <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-4">
              <Key className="w-5 h-5 text-primary" />
              <h3 className="font-bold font-display text-lg">Authentication</h3>
            </div>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="font-medium">Two-Factor Authentication</div>
                  <div className="text-sm text-muted-foreground">Secure your account with 2FA.</div>
                </div>
                <Switch checked={twoFactor} onCheckedChange={setTwoFactor} />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="font-medium">Passwordless Login</div>
                  <div className="text-sm text-muted-foreground">Use biometric or magic links.</div>
                </div>
                <Button variant="outline" size="sm">Setup</Button>
              </div>
              <div className="pt-4 border-t border-border/50">
                <Button variant="secondary" className="w-full bg-primary/10 text-primary hover:bg-primary/20">
                  Change Password
                </Button>
              </div>
            </div>
          </Card>

          {/* Privacy Settings */}
          <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-4">
              <Eye className="w-5 h-5 text-accent" />
              <h3 className="font-bold font-display text-lg">Privacy & Visibility</h3>
            </div>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="font-medium">Public Profile</div>
                  <div className="text-sm text-muted-foreground">Allow others to see your stats.</div>
                </div>
                <Switch checked={publicProfile} onCheckedChange={setPublicProfile} />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="font-medium">Login Alerts</div>
                  <div className="text-sm text-muted-foreground">Notify on new device login.</div>
                </div>
                <Switch checked={loginAlerts} onCheckedChange={setLoginAlerts} />
              </div>
              <div className="pt-4 border-t border-border/50">
                 <Button variant="destructive" className="w-full bg-red-500/10 text-red-500 hover:bg-red-500/20 border-none">
                   Delete Account Data
                 </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Security Audit Log */}
        <Card className="border-border/50 bg-card/30 backdrop-blur-sm overflow-hidden">
          <div className="p-6 border-b border-border/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold font-display text-lg">Recent Activity</h3>
            </div>
            <Button variant="ghost" size="sm" className="text-muted-foreground">View All</Button>
          </div>
          <div className="divide-y divide-border/50">
            {activityLog.map((log) => (
              <div key={log.id} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-full ${log.status === 'success' ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
                    {log.status === 'success' ? <CheckCircle className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{log.action}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Smartphone className="w-3 h-3" /> {log.device} • {log.location}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground font-mono">
                  {log.time}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Active Sessions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
           <Card className="p-4 border-green-500/30 bg-green-500/5 flex items-center gap-3">
             <div className="p-2 bg-green-500/20 rounded-full text-green-500"><CheckCircle className="w-5 h-5" /></div>
             <div>
               <div className="text-sm font-bold text-green-400">System Status</div>
               <div className="text-xs text-green-400/70">All Systems Operational</div>
             </div>
           </Card>
           <Card className="p-4 border-primary/30 bg-primary/5 flex items-center gap-3">
             <div className="p-2 bg-primary/20 rounded-full text-primary"><Shield className="w-5 h-5" /></div>
             <div>
               <div className="text-sm font-bold text-primary">Encryption</div>
               <div className="text-xs text-primary/70">AES-256 Enabled</div>
             </div>
           </Card>
           <Card className="p-4 border-yellow-500/30 bg-yellow-500/5 flex items-center gap-3">
             <div className="p-2 bg-yellow-500/20 rounded-full text-yellow-500"><AlertTriangle className="w-5 h-5" /></div>
             <div>
               <div className="text-sm font-bold text-yellow-500">Pending Audit</div>
               <div className="text-xs text-yellow-500/70">Scheduled for Nov 30</div>
             </div>
           </Card>
        </div>
      </div>
    </Layout>
  );
}
