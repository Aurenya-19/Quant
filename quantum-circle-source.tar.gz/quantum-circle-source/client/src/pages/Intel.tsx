import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Radio, Globe, ShieldAlert, Terminal, Cpu, Zap } from "lucide-react";

export default function Intel() {
  const threats = [
    { id: 1, title: "Zero-Day in Quantum Encryption Protocol", level: "Critical", type: "Security", time: "2 hours ago" },
    { id: 2, title: "AI Model Collapse Predicted in Sector 7", level: "High", type: "AI Risk", time: "5 hours ago" },
    { id: 3, title: "New Botnet 'SiliconSwarm' Detected", level: "Medium", type: "Malware", time: "12 hours ago" },
  ];

  const news = [
    { id: 1, title: "Neural Link v5.0 Approved for Beta Testing", category: "Biotech", source: "TechCrunch 2077" },
    { id: 2, title: "SpaceX Launches First Orbital Data Center", category: "Space", source: "Orbital News" },
    { id: 3, title: "Rust becomes mandatory for Kernel Development", category: "Coding", source: "DevDaily" },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
             <h1 className="text-4xl font-display font-bold text-glow mb-2 flex items-center gap-3">
               <Radio className="w-8 h-8 text-accent animate-pulse" />
               Global Intel Feed
             </h1>
             <p className="text-muted-foreground">Real-time threats, breakthroughs, and signal intercepts.</p>
          </div>
          <Badge variant="outline" className="border-red-500 text-red-500 px-4 py-2 animate-pulse bg-red-500/10">
            THREAT LEVEL: ELEVATED
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Threat Radar */}
          <Card className="lg:col-span-2 p-6 border-red-500/30 bg-red-500/5 backdrop-blur-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-20">
              <ShieldAlert className="w-32 h-32 text-red-500" />
            </div>
            <h2 className="text-2xl font-display font-bold text-red-400 mb-6 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6" /> Active Threats
            </h2>
            <div className="space-y-4 relative z-10">
              {threats.map(threat => (
                <div key={threat.id} className="flex items-center justify-between p-4 rounded-lg bg-black/40 border border-red-500/20 hover:border-red-500/50 transition-colors group cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-2 rounded-full ${threat.level === 'Critical' ? 'bg-red-500 animate-ping' : 'bg-orange-500'}`} />
                    <div>
                      <h3 className="font-bold font-mono group-hover:text-red-400 transition-colors">{threat.title}</h3>
                      <div className="flex gap-2 text-xs text-muted-foreground mt-1">
                        <Badge variant="outline" className="border-red-500/20 text-red-400 text-[10px]">{threat.type}</Badge>
                        <span>{threat.time}</span>
                      </div>
                    </div>
                  </div>
                  <Button size="sm" variant="ghost" className="text-red-400 hover:bg-red-500/10 hover:text-red-300">
                    Analyze
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          {/* Emerging Tech Radar */}
          <Card className="p-6 border-primary/30 bg-primary/5 backdrop-blur-sm flex flex-col">
            <h2 className="text-xl font-display font-bold text-primary mb-6 flex items-center gap-2">
              <Cpu className="w-5 h-5" /> Tech Radar
            </h2>
            <div className="flex-1 flex items-center justify-center relative">
              {/* Mock Radar UI */}
              <div className="w-48 h-48 rounded-full border border-primary/20 relative flex items-center justify-center">
                <div className="w-32 h-32 rounded-full border border-primary/20 relative flex items-center justify-center">
                   <div className="w-16 h-16 rounded-full border border-primary/20 bg-primary/5" />
                </div>
                <div className="absolute inset-0 border-r border-primary/20 animate-[spin_4s_linear_infinite]" />
                
                {/* Radar Blips */}
                <div className="absolute top-4 right-10 w-2 h-2 bg-accent rounded-full animate-pulse shadow-[0_0_10px_#a855f7]" title="Quantum AI" />
                <div className="absolute bottom-10 left-8 w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-[0_0_10px_#4ade80]" title="Bio-Computing" />
              </div>
            </div>
            <div className="mt-6 space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Detected Signals:</span>
                <span className="text-primary font-mono">12</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Scan Status:</span>
                <span className="text-primary font-mono animate-pulse">Active</span>
              </div>
            </div>
          </Card>
        </div>

        {/* News & Breakthroughs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="p-6 border-border/50 bg-card/30">
            <h2 className="text-xl font-display font-bold mb-4 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-400" /> Global News
            </h2>
            <div className="space-y-4">
              {news.map(item => (
                <div key={item.id} className="p-3 rounded-lg hover:bg-white/5 transition-colors border-l-2 border-transparent hover:border-blue-400">
                  <h3 className="font-bold text-sm mb-1">{item.title}</h3>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{item.source}</span>
                    <span className="text-blue-400">{item.category}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 border-border/50 bg-card/30">
            <h2 className="text-xl font-display font-bold mb-4 flex items-center gap-2">
              <Terminal className="w-5 h-5 text-green-400" /> Hacker News (Top)
            </h2>
             <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors">
                  <div className="text-green-400 font-mono font-bold">{i}.</div>
                  <div>
                    <h3 className="font-bold text-sm mb-1 hover:underline cursor-pointer">Show HN: A new way to visualize neural networks in 3D</h3>
                    <div className="text-xs text-muted-foreground">156 points by neon_coder | 42 comments</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
