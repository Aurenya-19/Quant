import { db } from "./db";
import { 
  users, 
  posts, 
  messages, 
  communities, 
  communityMembers,
  bounties,
  snippets,
  type User, 
  type InsertUser,
  type Post,
  type InsertPost,
  type Message,
  type InsertMessage,
  type Community,
  type InsertCommunity,
  type Bounty,
  type InsertBounty,
  type Snippet,
  type InsertSnippet
} from "@shared/schema";
import { eq, desc, and, or, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createPost(post: InsertPost): Promise<Post>;
  getPosts(limit?: number): Promise<Post[]>;
  
  getCommunities(): Promise<Community[]>;
  createCommunity(community: InsertCommunity): Promise<Community>;
  
  getBounties(): Promise<Bounty[]>;
  createBounty(bounty: InsertBounty): Promise<Bounty>;
  
  getSnippets(): Promise<Snippet[]>;
  createSnippet(snippet: InsertSnippet): Promise<Snippet>;
}

export class DrizzleStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const result = await db.insert(posts).values(insertPost).returning();
    return result[0];
  }

  async getPosts(limit: number = 50): Promise<Post[]> {
    return await db.select().from(posts).orderBy(desc(posts.createdAt)).limit(limit);
  }

  async getCommunities(): Promise<Community[]> {
    return await db.select().from(communities);
  }

  async createCommunity(insertCommunity: InsertCommunity): Promise<Community> {
    const result = await db.insert(communities).values(insertCommunity).returning();
    return result[0];
  }

  async getBounties(): Promise<Bounty[]> {
    return await db.select().from(bounties).orderBy(desc(bounties.createdAt));
  }

  async createBounty(insertBounty: InsertBounty): Promise<Bounty> {
    const result = await db.insert(bounties).values(insertBounty).returning();
    return result[0];
  }

  async getSnippets(): Promise<Snippet[]> {
    return await db.select().from(snippets).orderBy(desc(snippets.createdAt));
  }

  async createSnippet(insertSnippet: InsertSnippet): Promise<Snippet> {
    const result = await db.insert(snippets).values(insertSnippet).returning();
    return result[0];
  }
}

export const storage = new DrizzleStorage();
